import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:proj4dart/proj4dart.dart' as proj4;

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Coordinate Display',
      home: MapScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MapScreen extends StatefulWidget {
  @override
  _MapScreenState createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  GoogleMapController? mapController;
  TextEditingController xController = TextEditingController();
  TextEditingController yController = TextEditingController();
  TextEditingController latController = TextEditingController();
  TextEditingController lonController = TextEditingController();

  Set<Marker> _markers = {};

  late proj4.Projection projSource;
  late proj4.Projection projTarget;

  @override
  void initState() {
    super.initState();
    // Define the custom projection (EPSG:22391) for Tunisia
    proj4.Projection.add('EPSG:22391',
        '+proj=lcc +lat_1=36 +lat_0=36 +lon_0=9.9 +k_0=0.999625544 +x_0=0 +y_0=0 +a=6378249.2 +b=6356515 +towgs84=-263,6,431,0.0,0.0,0.0,0.0 +units=m +no_defs');
    projSource = proj4.Projection.get('EPSG:22391')!;
    projTarget = proj4.Projection.get('EPSG:4326')!; // WGS84 for Google Maps
  }

  void _onMapCreated(GoogleMapController controller) {
    mapController = controller;
  }

  void _convertAndShowOnMap() {
    try {
      // Parse user input: X (easting, entered as positive), Y (northing)
      double xInput = double.parse(xController.text);
      double y = double.parse(yController.text);
      double x = -xInput; // Negate X to match Tunisian projection convention

      // Transform from EPSG:22391 (Tunisian projection) to EPSG:4326 (WGS84)
      var point = proj4.Point(x: x, y: y);
      var transformed = projSource.transform(projTarget, point);
      double lat = transformed.y; // Latitude
      double lon = transformed.x; // Longitude

      // Update the read-only latitude and longitude fields
      latController.text = lat.toStringAsFixed(6);
      lonController.text = lon.toStringAsFixed(6);

      // Set the map position
      LatLng position = LatLng(lat, lon);

      // Move the camera to the transformed coordinates
      mapController?.animateCamera(CameraUpdate.newLatLng(position));

      // Add a marker at the location
      setState(() {
        _markers.clear();
        _markers.add(Marker(
          markerId: MarkerId('point'),
          position: position,
        ));
      });
    } catch (e) {
      // Handle invalid input or transformation errors
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content:
                Text('Error: Invalid coordinates or transformation failed')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Coordinate Displayer')),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Text(
              'Enter Coordinates STT',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),

          // Input fields for X and Y coordinates
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: xController,
                    decoration: InputDecoration(labelText: 'Y (Northing)'),
                    keyboardType: TextInputType.number,
                  ),
                ),
                SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: yController,
                    decoration:
                        InputDecoration(labelText: 'X (Easting, positive)'),
                    keyboardType: TextInputType.number,
                  ),
                ),
                SizedBox(width: 8),
                ElevatedButton(
                  onPressed: _convertAndShowOnMap,
                  child: Text('Show on Map'),
                ),
              ],
            ),
          ),
          // Google Map
          Expanded(
            child: GoogleMap(
              onMapCreated: _onMapCreated,
              initialCameraPosition: CameraPosition(
                target: LatLng(36, 9.9), // Default center (Tunisia)
                zoom: 10,
              ),
              markers: _markers,
            ),
          ),
          // Read-only fields for latitude and longitude
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: latController,
                    decoration: InputDecoration(labelText: 'Latitude'),
                    readOnly: true,
                  ),
                ),
                SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: lonController,
                    decoration: InputDecoration(labelText: 'Longitude'),
                    readOnly: true,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
